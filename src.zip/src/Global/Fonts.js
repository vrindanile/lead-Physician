export const BLACK = 'Roboto-Black';

export const BLACK_ITALIC = 'Roboto-BlackItalic';

export const BOLD = 'Roboto-Bold';

export const BOLD_ITALIC = 'Roboto-BoldItalic';

export const ITALIC = 'Roboto-Italic';

export const LIGHT = 'Roboto-Light';

export const LIGHT_ITALIC = 'Roboto-LightItalic';

export const MEDIUM = 'Roboto-Medium';

export const MEDIUM_ITALIC = 'Roboto-MediumItalic';

export const REGULAR = 'Roboto-Regular';

export const THIN = 'Roboto-Thin';

export const THIN_ITALIC = 'Roboto-ThinItalic';
